var
    moveTable,
    move = new Array(5);
//------------------------------------------------------------
function getShortsightedMove(color)
{
    moveTable = [];
    backupMainTable();
    collectAvailMoves(color, moveTable);
    calcMoveScores(color, moveTable, 1, maxDepth);
    var bestMove = getBestMove(moveTable);
    AI_move = moveTable[bestMove];
    restoreMainTable();
    log("***** best move: " + AI_move[0] + "," + AI_move[1] +
        " --> " + AI_move[2] + "," + AI_move[3] + " (score=" + AI_move[4] + ")");
}
//------------------------------------------------------------
function getBestMove(tbl)
{
    var max = tbl[0][4];
    var maxPos = 0;
    var maximums = [];
    for (var m = 1; m < tbl.length; m++)
        if (tbl[m][4] > max) {
            max = tbl[m][4];
            maxPos = m;
        }
    log("\n");
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][4] == max) {
            log("Adding move #" + (m+1) + " to candidates.");
            maximums.push(m);
        }
    if (maximums.length > 1) {
        log("\n(More than 1 optimum move. " +
            "Selecting random...)");
        return maximums[Math.floor(Math.random()*
            (maximums.length))];
    }
    else return maxPos;
}
//------------------------------------------------------------
function collectAvailMoves(color, tbl)
{
    for (var i = 0; i < tableSize; i++) {
        for (var j = 0; j < tableSize; j++) {
            if (getTileStatus(i, j) == color) {
                //-- UP
                if ((i > 0) &&
                    (validMove(color, i, j, i - 1, j))) {
                    move = [i, j, i - 1, j];
                    tbl.push(move);
                }
                //-- DOWN
                if ((i < tableSize - 1) &&
                    (validMove(color, i, j, i + 1, j))) {
                    move = [i, j, i + 1, j];
                    tbl.push(move);
                }
                //-- LEFT
                if ((j > 0) &&
                    (validMove(color, i, j, i, j - 1))) {
                    move = [i, j, i, j - 1];
                    tbl.push(move);
                }
                //-- RIGHT
                if ((j < tableSize - 1) &&
                    (validMove(color, i, j, i, j + 1))) {
                    move = [i, j, i, j + 1];
                    tbl.push(move);
                }
            }
        }
    }
}
//------------------------------------------------------------
function calcMoveScores(color, tbl, sign, depth)
{
    for (var m = 0; m < tbl.length; m++ ) {
        tbl[m][4] = sign * getMoveScore(color, tbl, m, depth);
        tbl[m][5] = null;
    }
}
//------------------------------------------------------------
function backupMainTable()
{
    for (var i = 0; i < tableSize; i++) {
        for (var j = 0; j < tableSize; j++) {
            backupTable[i][j] = mainTable[i][j];
        }
    }
    numOfPawnsInBaseBackup[blue] = numOfPawnsInBase[blue];
    numOfPawnsInBaseBackup[red] = numOfPawnsInBase[red];
}
//------------------------------------------------------------
function restoreMainTable()
{
    for (var i = 0; i < tableSize; i++) {
        for (var j = 0; j < tableSize; j++) {
            mainTable[i][j] = backupTable[i][j];
        }
    }
    numOfPawnsInBase[blue] = numOfPawnsInBaseBackup[blue];
    numOfPawnsInBase[red] = numOfPawnsInBaseBackup[red];
}
//------------------------------------------------------------
function getMoveScore(color, tbl, m, depth)
{
    var backupTbl = [];
    var backupBase = [];
    if (tileInBase(tbl[m][2], tbl[m][3], enemyColor(color))) {
        return 100;
    }
    if (tileAdjacentToBase(tbl[m][2], tbl[m][3],
        enemyColor(color))) {
        return 50;
    }
    if (tileIsHotCorner(tbl[m][2], tbl[m][3], color)) {
        return 50;
    }
    backupTbl = deepCopy(mainTable);
    backupBase = numOfPawnsInBase.slice();
    doVirtualMove(color, tbl, m);
    var ownVanishes = numOfVanishingPawns(color);
    var enemyVanishes= numOfVanishingPawns(enemyColor(color));
    mainTable = deepCopy(backupTbl);
    numOfPawnsInBase = backupBase.slice();
    return (enemyVanishes - ownVanishes)*100/numberOfPawns;
}
//------------------------------------------------------------
function doVirtualMove(color, tbl, m)
{
    var startI = tbl[m][0];
    var startJ = tbl[m][1];
    var endI = tbl[m][2];
    var endJ = tbl[m][3];
    if (!((tileInBase(startI, startJ, color)) &&
        (numOfPawnsInBase[color] > 1)))
        mainTable[startI][startJ] = blank;
    mainTable[endI][endJ] = color;
    if (tileInBase(startI, startJ, color))
        numOfPawnsInBase[color]--;
}
//------------------------------------------------------------
function numOfVanishingPawns(color)
{
    var res = 0;
    var baseCalced = false;
    for (var i = 0; i < tableSize; i++) {
        for (var j = 0; j < tableSize; j++) {
            if ((getTileStatus(i, j) == color) &&
                (numOfValidMoves(i, j) == 0)) {
                if (tileInBase(i, j, color)) {
                    if (!baseCalced) {
                        baseCalced = true;
                        res += numOfPawnsInBase[color];
                    }
                }
                else res++;
            }
        }
    }
    return res;
}