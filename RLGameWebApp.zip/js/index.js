var
    mainCanvas, mainCanvasContext, bgCanvas, bgCanvasContext,
    tileImg, blueBaseImg, redBaseImg, mainTable, backupTable,
    backgroundImg, fireworksImg, cloudImg, trophyImg, homeImg,
    gearImg, blueTotalCounter, blueBaseCounter,
    redTotalCounter, redBaseCounter, selMarkImg,
    targetMarkImg, winStatus, playerTurn, tileSize,
    tilePadding, tileHalfSize, pawnSize, pawnHalfSize,
    musicSnd, whirlSnd, tadaSnd, tickSnd, wooshSnd, tapX,
    tapY, tapTileI, tapTileJ, onlineColor, gameID,

    logStatus = false,
    pawnImg = [],
    opponents = [],
    numOfPawnsInBase = [],
    numOfPawnsInBaseBackup = [],
    numOfPawns = [],
    blank = -1,
    blue = 0,
    red = 1,
    human = 0,
    computer = 1,
    local = 0,
    online = 1,
    onlinePlayerType = blank,
    selTileI = -1,
    selTileJ = -1,
    moveInProgress = false,
    tableSize = 8,
    baseSize = 2,
    numberOfPawns = 10,
    doubleEventPrevent = false,
    useMinimax = true,
    useRL = true,
    useShadows = true,
    useSounds = true,
    useMusic = true,
    paused = false,
    gameType = local,
    AI_move = [];

//------------------------------------------------------------
function adjustLayout()
{
    adjustCanvasSize();
    tileSize = Math.round(mainCanvas.width/tableSize);
    tileHalfSize = Math.round(tileSize/2);
    tilePadding = Math.round(tileSize/10);
    pawnSize = tileSize - 2*tilePadding;
    pawnHalfSize = Math.round(pawnSize/2);
    document.getElementById("headerDivTable").width =
        mainCanvas.width;
    document.getElementById("footerDivTable").width =
        mainCanvas.width;
    document.getElementById("canvasDiv").width =
        mainCanvas.width;
    drawBackground();
    mainCanvasContext.shadowColor = '#555';
}
//------------------------------------------------------------
function onBodyLoad()
{
	document.addEventListener("deviceready",
        onDeviceReady, false);
	mainCanvas = document.getElementById("mainCanvas");
    bgCanvas = document.getElementById("bgCanvas");
	mainCanvas.addEventListener("mousedown",
        mainCanvasClick, false);
	mainCanvasContext = mainCanvas.getContext("2d");
    bgCanvasContext = bgCanvas.getContext("2d");
    blueTotalCounter =
        document.getElementById("blueTotalCounter");
    blueBaseCounter =
        document.getElementById("blueBaseCounter");
    redTotalCounter =
        document.getElementById("redTotalCounter");
    redBaseCounter =
        document.getElementById("redBaseCounter");
    createDOMEvents();
    mainTable = new Array(tableSize);
    backupTable = new Array(tableSize);
    opponents[blue] = human;
    opponents[red] = computer;
    onlinePlayerType = 0;
    logging(false);
    assignMedia();
    if (!mobileApp()) {
        visibleElement("splashDiv", false);
        visibleElement("pageDiv", true);
    }
    adjustLayout();
    startNewGame();
    if (!mobileApp()) setTimeout(function() {
        $("#optionsPopup").popup("open");
    }, 600);
}
//------------------------------------------------------------
function createDOMEvents()
{
    $(window).resize(function() {
        if (moveInProgress) return;
        adjustLayout();
        clearAllMarks();
        invalidateSelPos();
    });
    $(document).on("popupafteropen", "#optionsPopup",
        function () {
        paused = true;
        playSound(musicSnd);
    });
    $(document).on("popupafterclose", "#optionsPopup",
        function () {
        paused = false;
        stopSound(musicSnd);
        if (((gameType == local) &&
            (opponents[playerTurn] == computer)) ||
            ((gameType == online) &&
                (onlinePlayerType == computer) &&
                (onlineColor == playerTurn)))
            artificialAction(playerTurn);
        else if ((gameType == online) &&
            (onlineColor != playerTurn)) waitOnlineMove();
        $('#gameTypeCollapsible').trigger('expand');
    });
    $( "#slider-1" ).bind( "change", function(event, ui) {
        var tableSizeValue =
            document.getElementById("slider-1").value;
        var baseSizeMaxValue = parseInt(tableSizeValue/2);
        if (tableSizeValue == 2*baseSizeMaxValue)
            baseSizeMaxValue--;
        document.getElementById("slider-2").max =
            baseSizeMaxValue;
        if (document.getElementById("slider-2").value >
            baseSizeMaxValue)
            document.getElementById("slider-2").value =
                baseSizeMaxValue;
    });
    $( "#slider-4" ).bind( "change", function(event, ui) {
        maxDepth = document.getElementById("slider-4").value;
    });
}
//------------------------------------------------------------
function startNewGame()
{
    document.getElementById("blue" +
        "TurnIndicator").style.visibility = 'visible';
    document.getElementById("red" +
        "TurnIndicator").style.visibility = 'hidden';
    tableSize = document.getElementById("slider-1").value;
    baseSize = document.getElementById("slider-2").value;
    numberOfPawns = document.getElementById("slider-3").value;
    adjustLayout();
    mainTable = new Array(tableSize);
    backupTable = new Array(tableSize);
    initMainTable();
    mainCanvasContext.clearRect(0, 0, mainCanvas.width,
        mainCanvas.height);
    clearAllMarks();
    updatePawnCounters();
    numOfPawns[blue] = numOfPawns[red] =
        numOfPawnsInBase[blue] = numOfPawnsInBase[red] =
            numberOfPawns;
    updatePawnCounters();
    invalidateSelPos();
    statusHistory = [];
    moveInProgress = false;
    winStatus = blank;
    playerTurn = blue;
    paused = false;
    setTimeout(function() {
        setTileStatus(tableSize - 1, 0, blue);
        setTileStatus(0, tableSize - 1, red);
        $("#optionsPopup").popup("close");
    }, 500);
}
//------------------------------------------------------------
function waitOnlineMove()
{
    var xmlhttp, xmlhttp2, url, color, i1, j1, i2, j2;
    var waitingFor = "i1";
    color = strCol(enemyColor(onlineColor));
    if (onlineColor == playerTurn) return;
    showTempMsg("", "<div style='text-align: center;'><h4>" +
        "Waiting for the <img src='res/img/" + color +
        "PawnCounterImg.png' height='20px'/> " +
        "player...</h4></div>", "b", 1);
    color = strCol(playerTurn) + "_";
    if (window.XMLHttpRequest) {
        try {
            xmlhttp = new XMLHttpRequest();
            xmlhttp2 = new XMLHttpRequest();
        } catch (ex) {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            xmlhttp2 = new ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    xmlhttp.onreadystatechange = function() {
        if ((xmlhttp.readyState == 4) &&
            (xmlhttp.status == 200)) {
            var resp = xmlhttp.responseText;
            if (resp != "") eval(waitingFor + " = " +
                xmlhttp.responseText);
            else eval(waitingFor + " = ''");
           if (waitingFor == "i1") waitingFor = "j1";
            else if (waitingFor == "j1") waitingFor = "i2";
            else if (waitingFor == "i2") waitingFor = "j2";
            else if (waitingFor == "j2") waitingFor = "";
            if (waitingFor != "") {
                url = "php/retrieve.php?gid=" + gameID +
                    "&field=" + color + waitingFor;
                xmlhttp.open("GET", url, true);
                xmlhttp.send();
            }
            else {
                var moveReceived = (i1 >= 0) && (j1 >= 0) &&
                    (i2 >= 0) && (j2 >= 0);
                if (moveReceived) {
                   xmlhttp2.onreadystatechange = function() {
                        if ((xmlhttp2.readyState == 4) &&
                            (xmlhttp.status == 200)) {
                            //log("CLEAR SQL RESPONSE: " +
                            //xmlhttp2.responseText);
                        }
                    };
                    url = "php/clear.php?gid=" + gameID +
                        "&color=" + color;
                    xmlhttp2.open("GET", url, true);
                    xmlhttp2.send();
                    setSelTile(i1, j1, false);
                    moveSelPawnToPos(i2, j2);
                }
                else {
                    setTimeout(function() {
                        waitOnlineMove();
                    }, 1000);
                }
            }
        }
    };
    url = "php/retrieve.php?gid=" + gameID + "&field=" +
        color + waitingFor;
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
//------------------------------------------------------------
function sendOnlineMove(gid, color, i1, j1, i2, j2)
{
    var xmlhttp;
    if (window.XMLHttpRequest) {
        try {
            xmlhttp = new XMLHttpRequest();
        } catch (ex) {
            xmlhttp =
                new window.ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    xmlhttp.onreadystatechange = function() {
        if ((xmlhttp.readyState == 4) &&
            (xmlhttp.status == 200)) {
            //log(xmlhttp.responseText);
        }
    };
    var url = "php/move.php?gid=" + gid + "&color=" + color +
        "&i1=" + i1 + "&j1=" + j1 + "&i2=" + i2 + "&j2=" + j2;
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
//------------------------------------------------------------
function connectOnlineGame()
{
    var xmlhttp, xmlhttp2;
    gameID = document.getElementById("gameID").value;
    showTempMsg("Connecting to server...", "", "b", 0);
    if (window.XMLHttpRequest) {
        try {
            xmlhttp = new XMLHttpRequest();
            xmlhttp2 = new XMLHttpRequest();
        } catch (ex) {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            xmlhttp2 = new ActiveXObject("Microsoft.XMLHTTP");
        }
    }
    xmlhttp.onreadystatechange = function() {
        if ((xmlhttp.readyState == 4) &&
            (xmlhttp.status == 200)) {
            onlineColor = parseInt(xmlhttp.responseText);
            hideTempMsg();
            if (onlineColor == blue) {
                tableSize =
                    document.getElementById("slider-1").value;
                baseSize =
                    document.getElementById("slider-2").value;
                numberOfPawns =
                    document.getElementById("slider-3").value;
                sendOnlineGameSettings(gameID);
                showTempMsg("Game created. Waiting for " +
                    "opponent...", "", "d", 0);
                var connRetries = 10;
                xmlhttp2.onreadystatechange = function() {
                    if ((xmlhttp2.readyState == 4) &&
                        (xmlhttp2.status == 200)) {
                        var rla = xmlhttp2.responseText;
                        if ((rla == "") && (connRetries > 0)){
                            setTimeout(function() {
                                connRetries--;
                                xmlhttp2.open("GET",
                                    "php/retrieve.php?gid=" +
                                        gameID +
                                        "&field=red" +
                                        "_last_access", true);
                                xmlhttp2.send();
                            }, 2000);
                        }
                        if (rla != "") {
                            connRetries = 0;
                            hideTempMsg();
                            adjustLayout();
                            setTileStatus(tableSize - 1, 0,
                                blue);
                            setTileStatus(0, tableSize - 1,
                                red);
                            $("#optionsPopup").popup("close");
                            showTempMsg("", "<div style=" +
                                "'text-align: center;'><h3>" +
                                "You are the <img src=" +
                                "'res/img/bluePawnCounterImg"+
                                ".png' height='20px'/> " +
                                "player.<br>Starting game..."+
                                "</h3></div>", "e", 2);
                        }
                        if ((rla == "") &&
                            (connRetries == 0)) {
                            hideTempMsg();
                            showTempMsg("", "<div style=" +
                                "'text-align: center;'><h3>" +
                                "No response from<br>the " +
                                "<img src='res/img/red" +
                                "PawnCounterImg.png' height" +
                                "='20px'/> player.</h3>" +
                                "</div>", "e", 2);
                        }
                    }
                };
                xmlhttp2.open("GET", "php/retrieve.php?gid=" +
                    gameID + "&field=red_last_access", true);
                xmlhttp2.send();
            }
            else if (onlineColor == red) {
                showTempMsg("", "<div style='text-align: " +
                    "center;'><h3>You are the <img src=" +
                    "'res/img/redPawnCounterImg.png' height" +
                    "='20px'/> player.<br>Starting game..." +
                    "</h3></div>", "e", 2);
                setTimeout(function() {
                    getOnlineGameSettings(gameID);
                    document.getElementById("slider-1").value=
                        tableSize;
                    document.getElementById("slider-2").value=
                        baseSize;
                    document.getElementById("slider-3").value=
                        numberOfPawns;
                    adjustLayout();
                    setTileStatus(tableSize - 1, 0, blue);
                    setTileStatus(0, tableSize - 1, red);
                    $("#optionsPopup").popup("close");
                }, 2000);
            }
            else showTempMsg("", "<div style='text-align: " +
                    "center;'><h3>Game_ID already exists." +
                    "<br>Please select another.</h3></div>",
                    "e", 2);
        }
    };
    var url = "php/connect.php?gid=" + gameID;
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
//------------------------------------------------------------
function sendOnlineGameSettings(gameID)
{
    // blue_i1 : tableSize
    // blue_j1 : baseSize
    // blue_i2 : numberOfPawns
    syncAjaxCall("php/move.php?gid=" + gameID + ":settings" +
        "&color=0&i1=" + tableSize + "&j1=" + baseSize +
        "&i2=" + numberOfPawns + "&j2=-1");
}
//------------------------------------------------------------
function getOnlineGameSettings(gameID)
{
    // blue_i1 : tableSize
    // blue_j1 : baseSize
    // blue_i2 : numberOfPawns
    tableSize = syncAjaxCall("php/retrieve.php?gid=" +
        gameID + ":settings" + "&field=blue_i1");
    baseSize = syncAjaxCall("php/retrieve.php?gid=" +
        gameID + ":settings" + "&field=blue_j1");
    numberOfPawns = syncAjaxCall("php/retrieve.php?gid=" +
        gameID + ":settings" + "&field=blue_i2");
}
//------------------------------------------------------------
function showTempMsg(txtMsg, htmlMsg, theme, duration)
{
    $.mobile.loading( "show", {
        text: txtMsg,
        textVisible: true,
        theme: theme,
        html: htmlMsg
    });
    if (duration>0) {
        setTimeout(function() {
            $.mobile.loading('hide');
        }, duration*1000);
    }
}
//------------------------------------------------------------
function hideTempMsg()
{
    $.mobile.loading('hide');
}
//------------------------------------------------------------
function mobileApp()
{
    return !(typeof window.cordova === 'undefined');
}
//------------------------------------------------------------
function playSound(snd)
{
    if (snd == musicSnd) {
        if (useMusic) snd.play();
    }
    else if (useSounds) snd.play();
}
//------------------------------------------------------------
function stopSound(snd)
{
    snd.pause();
    snd.currentTime = 0;
}
//------------------------------------------------------------
function setSound()
{
    useSounds = ($('#flip-1').val() == "on");
}
//------------------------------------------------------------
function setMusic()
{
    useMusic = ($('#flip-2').val() == "on");
    if (useMusic) playSound(musicSnd);
    else stopSound(musicSnd);
}
//------------------------------------------------------------
function setMinimax()
{
    useMinimax = ($('#flip-3').val() == "on");
    if (useMinimax) {
        $('#flip-4').slider('enable');
        $('#flip-4').val("on");
        $('#slider-4').slider('enable');
        showTempMsg("", "<div style='text-align: center;'>" +
            "<h3>MODE: Minimax + RL</h3></div>", "b", 1);
    }
    else {
        $('#flip-4').val("off");
        $('#flip-4').slider('disable');
        $('#slider-4').slider('disable');
        showTempMsg("", "<div style='text-align: center;'>" +
            "<h3>MODE: Shortsighted</h3></div>", "b", 1);
    }
    $('#flip-4').slider('refresh');
    $('#slider-4').slider('refresh');
    setRL(false);
}
//------------------------------------------------------------
function setRL(msg)
{
    useRL = ($('#flip-4').val() == "on");
    if (!msg) return;
    if (useRL) {
        if (useMinimax) showTempMsg("", "<div style='text-align: " +
            "center;'><h3>MODE: Minimax + RL</h3></div>", "b", 1);
        else showTempMsg("", "<div style='text-align: " +
            "center;'><h3>MODE: RL</h3></div>", "b", 1);
    }
    else {
        if (useMinimax) showTempMsg("", "<div style='text-align: center;'>" +
            "<h3>MODE: Minimax</h3></div>", "b", 1);
        else showTempMsg("", "<div style='text-align: " +
            "center;'><h3>MODE: Shortsighted</h3></div>", "b", 1);
    }
}
//------------------------------------------------------------
function updatePawnCounters()
{
    blueTotalCounter.textContent = numOfPawns[blue];
    blueBaseCounter.textContent = numOfPawnsInBase[blue];
    redTotalCounter.textContent = numOfPawns[red];
    redBaseCounter.textContent = numOfPawnsInBase[red];
}
//------------------------------------------------------------
function setShadow(status)
{
	if (!useShadows) return;
    if (status) mainCanvasContext.shadowOffsetX =
        mainCanvasContext.shadowOffsetY =
            mainCanvasContext.shadowBlur = 3;
	else mainCanvasContext.shadowOffsetX =
        mainCanvasContext.shadowOffsetY =
            mainCanvasContext.shadowBlur =
                mainCanvasContext.shadowBlur = 0;
}
//------------------------------------------------------------
function assignMedia()
{
	backgroundImg = document.getElementById("backgroundImg");
    tileImg = document.getElementById("tileImg");
    blueBaseImg = document.getElementById("blueBaseImg");
    redBaseImg = document.getElementById("redBaseImg");
	pawnImg[blue] = document.getElementById("bluePawnImg1");
	pawnImg[red] = document.getElementById("redPawnImg1");
	selMarkImg = document.getElementById("selMarkImg");
	targetMarkImg = document.getElementById("targetMarkImg");
    fireworksImg = document.getElementById("fireworksImg");
    cloudImg = document.getElementById("cloudImg");
    trophyImg = document.getElementById("trophyImg");
    homeImg = document.getElementById("homeImg");
    gearImg = document.getElementById("gearImg");
    if (!mobileApp()) {
        musicSnd = document.getElementById("musicSnd");
        tickSnd = document.getElementById("tickSnd");
    	whirlSnd = document.getElementById("whirlSnd");
        tadaSnd = document.getElementById("tadaSnd");
        wooshSnd = document.getElementById("wooshSnd");
    }
}
//------------------------------------------------------------
function adjustCanvasSize()
{
	mainCanvas.height = window.innerHeight -
        ($("#headerDiv").outerHeight() +
            $("#aboveDiv").outerHeight() +
            $("#footerDiv").outerHeight() + 3);
	if (mainCanvas.height > window.innerWidth) {
		mainCanvas.height = window.innerWidth;
		mainCanvas.width = mainCanvas.height;
	}
	else mainCanvas.width = mainCanvas.height;
    setShadow(true);
    bgCanvas.height = mainCanvas.height;
    bgCanvas.width = mainCanvas.width;
    bgCanvas.style.display = "block";
    mainCanvas.style.display = "block";
}
//------------------------------------------------------------
function initMainTable()
{
	for (var i = 0; i < tableSize; i++) {
		mainTable[i] = new Array(tableSize);
        backupTable[i] = new Array(tableSize);
		for (var j = 0; j < tableSize; j++)
			setTileStatus(i, j, blank);
	}
}
//------------------------------------------------------------
function onDeviceReady()
{
    musicSnd =
     new Media("/android_asset/www/res/snd/mp3/musicSnd.mp3");
    tickSnd =
      new Media("/android_asset/www/res/snd/mp3/tickSnd.mp3");
    whirlSnd =
     new Media("/android_asset/www/res/snd/mp3/whirlSnd.mp3");
    tadaSnd =
      new Media("/android_asset/www/res/snd/mp3/tadaSnd.mp3");
    wooshSnd =
     new Media("/android_asset/www/res/snd/mp3/wooshSnd.mp3");
    visibleElement("splashDiv", false);
    visibleElement("pageDiv", true);
    setTimeout(function() {
        $("#optionsPopup").popup("open");
    }, 600);
}
//------------------------------------------------------------
function visibleElement(elm, status)
{
    if (status) document.getElementById(elm).style.display=
        "block";
    else document.getElementById(elm).style.display="none";
}
//------------------------------------------------------------
function displayWinFireworks(color)
{
    var firePadding = Math.round(mainCanvas.width/10);
    var fireSize =
        Math.round(mainCanvas.width - 2*firePadding);
    var cloudPadding = 2*firePadding;
    var cloudSize =
        Math.round(mainCanvas.width - 2*cloudPadding);
    var pawnPadding =
        Math.round(mainCanvas.width/2 -
            1.5*mainCanvas.width/8);
    var pawnSize = Math.round(2.5*mainCanvas.width/8);
    var trophyPadding =
        Math.round(mainCanvas.width/2 -
            0.5*mainCanvas.width/8);
    var trophySize = 1.5*mainCanvas.width/8;
    setShadow(false);
    mainCanvasContext.drawImage(cloudImg, cloudPadding,
        cloudPadding, cloudSize, cloudSize);
    mainCanvasContext.drawImage(fireworksImg, firePadding,
        firePadding, fireSize, fireSize);
    mainCanvasContext.drawImage(pawnImg[color], pawnPadding,
        pawnPadding - tileSize/3, pawnSize, pawnSize);
    mainCanvasContext.drawImage(trophyImg, trophyPadding,
        trophyPadding - tileSize/2, trophySize, 1.5*trophySize);
    setShadow(true);
    playSound(tadaSnd);
}
//------------------------------------------------------------
function mainCanvasClick(e)
{
    if ((doubleEventPrevent) && (mobileApp())) return;
    doubleEventPrevent = true;
    setTimeout(function(){ doubleEventPrevent= false; }, 500);
    if (winStatus != blank) {
        setTimeout(function() {
            $("#optionsPopup").popup("open");
        }, 100);
        return;
    }
    if ((moveInProgress)
        || ((gameType == local) &&
        (opponents[playerTurn] == computer))
        || ((gameType == online) &&
        (playerTurn != onlineColor)))
        return;
	getTapTile(e);
	if (getTileStatus(tapTileI, tapTileJ) == playerTurn)
        setSelTile(tapTileI, tapTileJ, true);
	else {
        if ((tileSelected()) &&
            ((getTileStatus(tapTileI, tapTileJ) == blank) ||
                (tileInBase(tapTileI, tapTileJ,
                    enemyColor(playerTurn)))))
            moveSelPawnToPos(tapTileI, tapTileJ);
        else playSound(wooshSnd);
    }
}
//------------------------------------------------------------
function setWinStatus(color)
{
    winStatus = color;
    updatePawnCounters();
    displayWinFireworks(color);
    paused = true;
    setTimeout(function() {
        if (useRL) {
            var mTable =[];
            var RLNode = new RLNODE(mainTable,
                numOfPawnsInBase, mTable);
            RLNode.cleanupBases();
            RLNode.lookupDBRLScore(color);
            RLNode.updateDBRLScore(color, 100);
            RLNode.pushToHistory();
            correctHistory(color);
        }
        if ((opponents[blue] == computer) &&
            (opponents[red] == computer)) {
            setTimeout(function() {
                $("#optionsPopup").popup("open");
                consoleClear();
                startNewGame();
            }, 500);
        }
    }, 100);
}
//------------------------------------------------------------
function checkGameConditions()
{
	checkForVanishes();
    checkForZeroPawns();
}
//------------------------------------------------------------
function checkForZeroPawns()
{
    if (moveInProgress) {
        setTimeout(function() {checkForZeroPawns();},500);
        return;
    }
    if (numOfPawns[blue] == 0) setWinStatus(red);
    else if (numOfPawns[red] == 0) setWinStatus(blue);
}
//------------------------------------------------------------
function checkForVanishes()
{
    var vanishTable = new Array(tableSize);
	for (var i = 0; i < tableSize; i++) {
        vanishTable[i] = new Array(tableSize);
		for (var j = 0; j < tableSize; j++)
            vanishTable[i][j] = (numOfValidMoves(i, j) == 0);
    }
    for (i = 0; i < tableSize; i++)
        for (j = 0; j < tableSize; j++)
            if (vanishTable[i][j]) vanishPawn(i, j);
}
//------------------------------------------------------------
function numOfValidMoves(i, j)
{
    var row, col;
    var availMoves = 0;
    var color = getTileStatus(i, j);
    if (tileInBase(i, j, color))
        if (color == blue) {
            i = tableSize - baseSize;
            j = baseSize - 1;
        } else {
            i = baseSize - 1;
            j = tableSize - baseSize;
        }
    if (color != blank) {
        if ((i > 0) && (validMove(color, i, j, i - 1, j)))
            availMoves++;
        if ((j > 0) && (validMove(color, i, j, i, j - 1)))
            availMoves++;
        if ((i < tableSize - 1) &&
            (validMove(color, i, j, i + 1, j))) availMoves++;
        if ((j < tableSize - 1) &&
            (validMove(color, i, j, i, j + 1))) availMoves++;
        if (tileInBase(i, j, color)) {
            if (color == blue) {
                row = tableSize - baseSize - 1;
                for (col = 0; col < baseSize - 1; col++)
                    if (validMove(color, i, j, row, col))
                        availMoves++;
                col = baseSize;
                for (row = tableSize - baseSize + 1;
                     row < tableSize; row++)
                    if (validMove(color, i, j, row, col))
                        availMoves++;
            } else {
                row = baseSize;
                for (col = tableSize - baseSize + 1;
                     col < tableSize; col++)
                    if (validMove(color, i, j, row, col))
                        availMoves++;
                col = tableSize - baseSize - 1;
                for (row = 0; row < baseSize - 1; row++)
                    if (validMove(color, i, j, row, col))
                        availMoves++;
            }
        }
    }
    return availMoves;
}
//------------------------------------------------------------
function vanishPawn(i, j)
{
    if (moveInProgress) {
        setTimeout(function() {vanishPawn(i, j);},100);
        return;
    }
    var color = getTileStatus(i, j);
	if (color != blank) {
        playSound(whirlSnd);
		whirlPawn(i, j);
		setTileStatus(i, j, blank);
        if (!tileInBase(i, j, color)) numOfPawns[color]--;
        else {
            numOfPawns[color] -= numOfPawnsInBase[color];
            numOfPawnsInBase[color] = 0;
        }
	}
    updatePawnCounters();
}
//------------------------------------------------------------
function whirlPawn(i, j)
{
    moveInProgress = true;
    var rotAngle = 0.1;
    var rotDuration = 150;
    var color = getTileStatus(i, j);
	mainCanvasContext.save();
	mainCanvasContext.translate(getTileCenterX(i, j),
        getTileCenterY(i, j));
    var counter = 1;
    var currPawnSize = pawnSize;
	setShadow(false);
    var interval = setInterval(function() {
		if (counter>rotDuration) {
			clearInterval(interval);
			mainCanvasContext.restore();
			setShadow(true);
            moveInProgress = false;
			return;
		}
		mainCanvasContext.rotate(rotAngle);
		mainCanvasContext.clearRect(-pawnHalfSize,
            -pawnHalfSize, pawnSize, pawnSize);
		currPawnSize -= pawnSize/rotDuration;
		mainCanvasContext.drawImage(pawnImg[color],
            -currPawnSize/2, -currPawnSize/2, currPawnSize,
            currPawnSize);
		counter++;
	}, 0);
}
//------------------------------------------------------------
function moveSelPawnToPos(i, j)
{
    var color = getTileStatus(selTileI, selTileJ);
	if (!validMove(color, selTileI, selTileJ, i, j)) {
        playSound(wooshSnd);
        return;
    }
    moveInProgress = true;
    playSound(tickSnd);
    clearAllMarks();
    if (tileInBase(i, j, enemyColor(color))) {
        setTileStatus(selTileI, selTileJ, blank);
        setTileStatus(i, j, color);
        numOfPawnsInBase[enemyColor(color)]= 0;
        setWinStatus(color);
        if ((gameType == online) && (color == onlineColor))
            sendOnlineMove(gameID, color, selTileI, selTileJ, i, j);
        return;
    }
	if (tileInBase(selTileI, selTileJ, color))
        numOfPawnsInBase[color]--;
    var currX =
        getTileStartX(selTileI, selTileJ) + tilePadding;
    var currY =
        getTileStartY(selTileI, selTileJ) + tilePadding;
    var endX = getTileStartX(i, j) + tilePadding;
    var endY = getTileStartY(i, j) + tilePadding;
    var interval = setInterval(function() {
        if ((currX == endX) && (currY == endY)) {
           	clearInterval(interval);
			setTileStatus(i, j, color);
			if (!tileInBase(selTileI, selTileJ, color))
                setTileStatus(selTileI, selTileJ, blank);
            clearAllMarks();
            if ((gameType== online) && (color == onlineColor))
                sendOnlineMove(gameID, color, selTileI,
                    selTileJ, i, j);
			invalidateSelPos();
            moveInProgress = false;
            updatePawnCounters();
            checkGameConditions();
            setTimeout(function() {flipPlayerTurn();},100);
			return;
       	}
		mainCanvasContext.clearRect(currX, currY,
            tileSize, tileSize);
		if ((tileInBase(selTileI, selTileJ, color)) &&
            (numOfPawnsInBase[color]>0))
            setTileStatus(selTileI, selTileJ, color);
		if (currX < endX) currX++; else if (currX > endX)
            currX--;
		if (currY < endY) currY++; else if (currY > endY)
            currY--;
		mainCanvasContext.drawImage(pawnImg[color], currX,
            currY, pawnSize, pawnSize);
	}, 0);
}
//------------------------------------------------------------
function validMove(pawnColor, startI, startJ, endI, endJ)
{
    var startHorDistFromBase,
        startVerDistFromBase,
        endHorDistFromBase,
        endVerDistFromBase,
        startMaxDistFromBase,
        endMaxDistFromBase;
    if ((tileInBase(startI, startJ, pawnColor)) &&
        (numOfPawnsInBase[pawnColor] > 0) &&
        (tileAdjacentToBase(endI, endJ, pawnColor)) &&
        (getTileStatus(endI, endJ) == blank)) return true;
    if ((tileAdjacentToBase(startI, startJ,
        enemyColor(pawnColor))) &&
        (tileInBase(endI, endJ, enemyColor(pawnColor))))
        return true;
    if (pawnColor == blue) {
        startHorDistFromBase = startJ;
        startVerDistFromBase = tableSize - startI - 1;
        endHorDistFromBase = endJ;
        endVerDistFromBase = tableSize - endI - 1;
    } else {
        startHorDistFromBase = tableSize - startJ - 1;
        startVerDistFromBase = startI;
        endHorDistFromBase = tableSize - endJ - 1;
        endVerDistFromBase = endI;
    }
    if (startHorDistFromBase > startVerDistFromBase)
        startMaxDistFromBase = startHorDistFromBase;
    else startMaxDistFromBase = startVerDistFromBase;
    if (endHorDistFromBase > endVerDistFromBase)
        endMaxDistFromBase = endHorDistFromBase;
    else endMaxDistFromBase = endVerDistFromBase;
	return ((endMaxDistFromBase >= startMaxDistFromBase) &&
     (Math.abs(startI - endI) + Math.abs(startJ - endJ) == 1))
           && ((getTileStatus(endI, endJ) == blank) ||
        (tileInBase(endI, endJ, enemyColor(pawnColor))));
}
//------------------------------------------------------------
function tileInBase(i, j, color)
{
	if (color == blue) return (i >= tableSize - baseSize)
        && (j < baseSize);
	else if (color == red) return (i < baseSize) &&
        (j >= tableSize - baseSize);
	else return false;
}
//------------------------------------------------------------
function tileAdjacentToBase(i, j, color)
{
	if (color == blue)
        return ((i == tableSize - baseSize - 1) &&
            (j < baseSize)) || ((i >= tableSize - baseSize) &&
            (j == baseSize));
	else if (color == red)
        return ((i == baseSize) &&
            (j >= tableSize - baseSize)) || ((i < baseSize) &&
            (j == tableSize - baseSize - 1));
	else return false;
}
//------------------------------------------------------------
function tileIsHotCorner(i, j, color)
{
    if (color == blue)
        return ((i == baseSize) &&
            (j == tableSize - baseSize - 1) &&
            (getTileStatus(i - 1, j) == blank) &&
            (getTileStatus(i, j + 1) == blank));
    else if (color == red)
        return ((i == tableSize - baseSize - 1) &&
            (j == baseSize) &&
            (getTileStatus(i, j - 1) == blank) &&
            (getTileStatus(i + 1, j) == blank));
    else return false;
}
//------------------------------------------------------------
function invalidateSelPos()
{
    selTileI = -1;
    selTileJ = -1;
}
//------------------------------------------------------------
function flipPlayerTurn()
{
    if (opponents[enemyColor(playerTurn)] == computer)
        consoleClear();
    if (winStatus != blank) return;
    if (playerTurn == blue) {
        playerTurn = red;
        document.getElementById("blue" +
            "TurnIndicator").style.visibility = 'hidden';
        document.getElementById("red" +
            "TurnIndicator").style.visibility = 'visible';
    }
    else {
        playerTurn = blue;
        document.getElementById("blue" +
            "TurnIndicator").style.visibility = 'visible';
        document.getElementById("red" +
            "TurnIndicator").style.visibility = 'hidden';
    }
    if (paused) return;
    if (((gameType == local) &&
        (opponents[playerTurn] == computer)) ||
        ((gameType == online) &&
            (onlinePlayerType == computer) &&
            (onlineColor == playerTurn)))
        artificialAction(playerTurn);
    else if ((gameType == online) &&
        (onlineColor != playerTurn)) waitOnlineMove();
}
//------------------------------------------------------------
function artificialAction(color)
{
    var col;
    if ((color != playerTurn) || (winStatus != blank)) return;
    if (moveInProgress) {
        setTimeout(function() {artificialAction(color);},500);
        return;
    }
    col = strCol(color);
    if ((opponents[color] == computer) ||
        ((gameType == online) &&
            (onlineColor == playerTurn) &&
            (onlinePlayerType == computer))) {
        showTempMsg("", "<div style='text-align: center;'>" +
            "<h4><img src='res/img/" + col +
            "PawnCounterImg.png' height='20px'/>" +
            "<br>thinking...</h4></div>", "b", 0);
        setTimeout(function() {
            if (useMinimax) getMinimaxMove(color);
            else getShortsightedMove(color);
            setSelTile(AI_move[0], AI_move[1], false);
            moveSelPawnToPos(AI_move[2], AI_move[3]);
            hideTempMsg();
        }, 100);
    }
}
//------------------------------------------------------------
function setOpponents(color, kind)
{
    opponents[color] = kind;
}
//------------------------------------------------------------
function setOnlinePlayerType(kind)
{
    onlinePlayerType = kind;
}
//------------------------------------------------------------
function setGameType(type)
{
    gameType = type;
    if (type == online) {
        $('#opponents' +
            'LocalCollapsible').addClass('ui-disabled');
        $('#opponents' +
            'OnlineCollapsible').removeClass('ui-disabled');
    }
    else {
        $('#opponents' +
            'LocalCollapsible').removeClass('ui-disabled');
        $('#opponents' +
            'OnlineCollapsible').addClass('ui-disabled');
    }
}
//------------------------------------------------------------
function setPawnset(num)
{
    if (moveInProgress) {
        setTimeout(function() {setPawnset(num)}, 10);
        return;
    }
    mainCanvasContext.clearRect(0, 0, mainCanvas.width,
        mainCanvas.height);
    if (num == 3) {
        setShadow(false);
        useShadows = false;
    }
    else {
        useShadows = true;
        setShadow(true);
    }
    pawnImg[blue] =
        document.getElementById("bluePawnImg"+num.toString());
    pawnImg[red] =
        document.getElementById("redPawnImg"+num.toString());
    clearAllMarks();
    invalidateSelPos();
}
//------------------------------------------------------------
function tileSelected()
{
    return selTileI >= 0;
}
//------------------------------------------------------------
function setSelTile(i, j, showMarks)
{
	if ((tileSelected()) && ((selTileI != i) ||
        (selTileJ != j))) clearMark(selTileI, selTileJ);
    playSound(tickSnd);
	selTileI = i;
	selTileJ = j;
	clearAllMarks();
	if (showMarks) {
        popImage(selMarkImg, i, j, tileSize/2, false);
        indicateValidMoves(i, j);
    }
}
//------------------------------------------------------------
function enemyColor(color)
{
	if (color == blue) return red;
	else return blue;
}
//------------------------------------------------------------
function indicateValidMoves(i, j)
{
    var color = getTileStatus(i, j);
	for (var row = 0; row < tableSize; row++) {
		for (var col = 0; col < tableSize; col++) {
			if ((!tileInBase(row, col, color)) &&
                (validMove(color, i, j, row, col))
			&& ((getTileStatus(row, col) == blank) ||
                (tileInBase(row, col, enemyColor(color)))))
                popImage(targetMarkImg, row, col, tileSize/3,
                    true);
		}
	}
}
//------------------------------------------------------------
function getTileStartX(i, j)
{
	if (tileInBase(i, j, blue))
        return Math.round(baseSize*tileSize/2 - tileSize/2);
	else if (tileInBase(i, j, red))
        return Math.round(tableSize*tileSize -
            baseSize*tileSize/2 - tileSize/2);
	else return Math.round(j*tileSize);
}
//------------------------------------------------------------
function getTileStartY(i, j)
{
	if (tileInBase(i, j, blue))
        return Math.round(tableSize*tileSize -
            baseSize*tileSize/2 - tileSize/2);
	if (tileInBase(i, j, red))
        return Math.round(baseSize*tileSize/2 - tileSize/2);
	else return Math.round(i*tileSize);
}
//------------------------------------------------------------
function getTileCenterX(i, j)
{
	return Math.round(getTileStartX(i, j) + tileHalfSize);
}
//------------------------------------------------------------
function getTileCenterY(i, j)
{
	return Math.round(getTileStartY(i, j) + tileHalfSize);
}
//------------------------------------------------------------
function getTileStatus(i, j)
{
	if (tileInBase(i, j, blue)) {
		if (numOfPawnsInBase[blue] > 0) return blue;
		else return blank;
	}
	else if (tileInBase(i, j, red)) {
		if (numOfPawnsInBase[red] > 0) return red;
		else return blank;
	}
	else return mainTable[i][j];
}
//------------------------------------------------------------
function setTileStatus(i, j, status)
{
	mainTable[i][j] = status;
	clearTile(i, j);
	if (status != blank) putPawn(i, j, status);
}
//------------------------------------------------------------
function clearTile(i, j)
{
	mainCanvasContext.clearRect(getTileStartX(i, j),
								getTileStartY(i, j),
								tileSize,
								tileSize);
}
//------------------------------------------------------------
function putPawn(i, j, color)
{
	mainCanvasContext.drawImage(pawnImg[color],
								getTileStartX(i, j) +
                                    tilePadding,
								getTileStartY(i, j) +
                                    tilePadding,
								pawnSize,
								pawnSize);
}
//------------------------------------------------------------
function drawBackground()
{
    for (var i = 0; i < tableSize; i++)
        for (var j = 0; j < tableSize; j++) {
            if ((!tileInBase(i, j, blue)) &&
                (!tileInBase(i, j, red)))
            bgCanvasContext.drawImage(tileImg,
                getTileStartX(i, j), getTileStartY(i, j),
                tileSize, tileSize);
        }
    bgCanvasContext.drawImage(blueBaseImg,
        getTileStartX(tableSize - 1, 0) -
            Math.round((baseSize - 1)*tileSize/2),
        getTileStartY(tableSize - 1, 0) -
            Math.round((baseSize - 1)*tileSize/2),
        baseSize*tileSize, baseSize*tileSize);
    bgCanvasContext.drawImage(redBaseImg,
        getTileStartX(0, tableSize - 1) -
            Math.round((baseSize - 1)*tileSize/2),
        getTileStartY(0, tableSize - 1) -
            Math.round((baseSize - 1)*tileSize/2),
        baseSize*tileSize, baseSize*tileSize);
}
//------------------------------------------------------------
function popImage(img, i, j, finalSize, cleanUp)
{
    var counter = 1;
    var popDuration = 20;
    var currSize = 0;
    setShadow(false);
    if ((tileInBase(i, j, blue) || (tileInBase(i, j, red))) &&
        (img == targetMarkImg)) {
        mainCanvasContext.drawImage(img,
            getTileCenterX(i, j) - finalSize/2,
            getTileCenterY(i, j) - finalSize/2,
            finalSize,
            finalSize);
        return;
    }
    var interval = setInterval(function() {
        if (counter > popDuration) {
            clearInterval(interval);
            setShadow(true);
            return;
        }
        currSize += (finalSize)/popDuration;
        if (cleanUp) {
            mainCanvasContext.clearRect(getTileCenterX(i, j) -
                currSize/2,
                getTileCenterY(i, j) - currSize/2,
                currSize,
                currSize);
        }
        mainCanvasContext.drawImage(img,
            getTileCenterX(i, j) - currSize/2,
            getTileCenterY(i, j) - currSize/2,
            currSize,
            currSize);
        counter++;
    }, 0);
}
//------------------------------------------------------------
function clearMark(i, j)
{
	clearTile(i, j);
	putPawn(i, j, getTileStatus(i, j));
}
//------------------------------------------------------------
function clearAllMarks()
{
	for (var i = 0; i < tableSize; i++)
		for (var j = 0; j < tableSize; j++) {
			clearTile(i, j);
			if (getTileStatus(i, j) != blank) putPawn(i, j,
                getTileStatus(i, j));
		}
}
//------------------------------------------------------------
function getTapCoords(e)
{
    if (e.pageX || e.pageY) {
      tapX = e.pageX;
      tapY = e.pageY;
    }
    else {
      tapX = e.clientX + document.body.scrollLeft +
          document.documentElement.scrollLeft;
      tapY = e.clientY + document.body.scrollTop +
          document.documentElement.scrollTop;
    }

    var offs = document.getElementById("canvasDiv").offsetTop;
    tapX -= mainCanvas.offsetLeft;
    tapY -= offs;
}
//------------------------------------------------------------
function getTapTile(e)
{
	getTapCoords(e);
	tapTileI = Math.floor(tapY/tileSize);
	tapTileJ = Math.floor(tapX/tileSize);
	if (tileInBase(tapTileI, tapTileJ, blue)) {
		tapTileI = tableSize - 1;
		tapTileJ = 0;
	}
	else if (tileInBase(tapTileI, tapTileJ, red)) {
		tapTileI = 0;
		tapTileJ = tableSize - 1;
	}
}
//------------------------------------------------------------
function log(msg)
{
    if (logStatus) console.log(msg);
}
//------------------------------------------------------------
function logging(status)
{
    logStatus = status;
}
//------------------------------------------------------------
function deepCopy(arr)
{
    var copy = arr.slice();
    for (var i = 0; i < copy.length; i++) {
        if (copy[i] instanceof Array) {
            copy[i] = deepCopy(copy[i]);
        }
    }
    return copy;
}
//------------------------------------------------------------
function strCol(color)
{
    if (color == blue) return "blue";
    else return "red";
}
//------------------------------------------------------------
function consoleClear()
{
    if (!mobileApp()) console.clear();
}
//------------------------------------------------------------
function debug()
{
//
}