var
    alpha = 0.5,
    gamma = 1,
    lamda = 0.5,
    historyDepth = 10,
    //statusHistory = new Array(historyDepth);
    statusHistory = [];
//------------------------------------------------------------
function RLNODE(statusTable, pawnsInBase, moveTable) {
    this.statusTable = deepCopy(statusTable);
    this.pawnsInBase = pawnsInBase.slice();
    this.moveTable = deepCopy(moveTable);
    this.dbScore = [];
    this.dbScore[blue] = null;
    this.dbScore[red] = null;
    this.displayNode = function() {
        log("\n[displayNode]:\n");
        this.displayStatusTable();
        log("score(blue) = " + this.score(blue));
        log("score(red) = " + this.score(red));
        log("pawnsInBase[blue] = " + this.pawnsInBase[blue]);
        log("pawnsInBase[red] = " + this.pawnsInBase[red]);
        this.displayMoveTable();
    };
    this.displayStatusTable = function() {
        displayTable("-- statusTable:", this.statusTable);
    };
    this.displayMoveTable = function() {
        log("\n-- moveTable: (" + this.moveTable.length +
            " moves)");
        for (var m = 0; m < this.moveTable.length; m++) {
            log("    #" + (m+1) + " : (" +
                this.moveTable[m][0] + "," +
                this.moveTable[m][1] + ") -> (" +
                this.moveTable[m][2] + "," +
                this.moveTable[m][3] + ")");
        }
    };
    this.letterTile = function(i, j) {
        if (this.statusTable[i][j] == blue) return "b";
        else if (this.statusTable[i][j] == red) return "r";
        else return "-";
    };
    this.toHash = function() {
        var result = "";
        for (var i = 0; i < tableSize; i++)
            for (var j = 0; j < tableSize; j++)
                result += this.letterTile(i, j);
        result += baseSize.toString()
        result += "/" + pawnsInBase[blue].toString();
        result += "/" + pawnsInBase[red].toString();
        return result;
    };
    this.statusHash = this.toHash();
    this.lookupDBRLScore = function(color) {
        this.dbScore[color] =
            Number(syncAjaxCall("php/getRLScore.php?hash=" +
                this.statusHash + "&color=" + strCol(color)));
        this.dbScore[enemyColor(color)]= -this.dbScore[color];
        return this.dbScore[color];
    };
    this.updateDBRLScore = function(color, value) {
        log("update score (" + this.dbScore[color] + " --> " +
            value + ") for:");
        this.displayStatusTable();
        log("...with pawnsInBase[blue]=" +
            this.pawnsInBase[blue]);
        log("...with pawnsInBase[red]=" +
            this.pawnsInBase[red]);
        log("...and score(" + strCol(color) + ")=" +
            this.score(color));
        syncAjaxCall("php/updateRLScore.php?hash=" +
            this.statusHash + "&" + strCol(color) +
            "_score=" + value + "&" +
            strCol(enemyColor(color))+ "_score=" + (-value));
        this.dbScore[color] = value;
        this.dbScore[enemyColor(color)]= -this.dbScore[color];
        log("");
    };
    this.cleanupBases = function() {
        var win = blank;
        for (var i = tableSize - baseSize; i < tableSize; i++)
            for (var j = 0; j < baseSize; j++) {
                if (this.statusTable[i][j] == red) win = red;
                this.statusTable[i][j] = blank;
            }
        if (win == red) {
            this.statusTable[tableSize - 1][0] = red;
            this.pawnsInBase[blue] = 0;
        }
        else if (this.pawnsInBase[blue] > 0)
            this.statusTable[tableSize - 1][0] = blue;
        for (i = 0; i < baseSize; i++)
            for (j = tableSize-baseSize; j < tableSize; j++) {
                if (this.statusTable[i][j] == blue) win= blue;
                this.statusTable[i][j] = blank;
            }
        if (win == blue) {
            this.statusTable[0][tableSize - 1] = blue;
            this.pawnsInBase[red] = 0;
        }
        else if (this.pawnsInBase[red] > 0)
            this.statusTable[0][tableSize - 1] = red;
    };
    this.cleanupBases();
    this.pushToHistory = function() {
        for (var i = historyDepth - 2; i >= 0; i--)
            statusHistory[i + 1] = statusHistory[i];
        log("@@@@@@@ PUSHING TO HISTORY:");
        this.displayStatusTable();
        statusHistory[0] = this;
        log("@@@@ dbscore[blue]: " + this.dbScore[blue]);
        log("@@@@ dbscore[red]: " + this.dbScore[red] + "\n");
    };
    this.score = function(color) {
        if (((color == blue) &&
            (this.statusTable[0][tableSize - 1] == blue))
            || ((color == red) &&
            (this.statusTable[tableSize - 1][0] == red)))
                return 100;
        if (((color == red) &&
            (this.statusTable[0][tableSize - 1] == blue))
            || ((color == blue) &&
            (this.statusTable[tableSize - 1][0] == red)))
            return -100;
        var pawns = [];
        pawns[blue] = this.pawnsInBase[blue];
        pawns[red] = this.pawnsInBase[red];
        for (var i = 0; i < tableSize; i++)
            for (var j = 0; j < tableSize; j++)
                if ((this.statusTable[i][j] != blank) &&
                    (!tileInBase(i, j, blue)) &&
                    (!tileInBase(i, j, red)))
                    pawns[this.statusTable[i][j]]++;
        return (100*(pawns[color] - pawns[enemyColor(color)])/
            numberOfPawns);
    };
    this.weightedAvg = function(color, depth, knownScore,
                                newScore) {
        return Math.round((depth*knownScore + newScore)/
            (depth + 1));
    };
}
//------------------------------------------------------------
function getRLMove(color, tbl)
{
    var currRLNode, bestMove, allSame, i, wAvg, dbScore,
        currScore;
    var mTable = [];
    mTable = deepCopy(tbl);
    log("\nCHECKING RL KNOWLEDGE BASE (" + strCol(color) +
        " player)...\n");
    currRLNode =
        new RLNODE(mainTable, numOfPawnsInBase, mTable);
    for (var m = 0; m < currRLNode.moveTable.length; m++) {
        doVirtualMove(color, currRLNode.moveTable, m);
        virtualCheckForVanishes();
        currRLNode.moveTable[m][5] =
            new RLNODE(mainTable, numOfPawnsInBase, mTable);
        dbScore =
            currRLNode.moveTable[m][5].lookupDBRLScore(color);
        currRLNode.moveTable[m][4] = dbScore;
        log("Possible move (" + currRLNode.moveTable[m][0] +
            "," + currRLNode.moveTable[m][1] + ")->(" +
            currRLNode.moveTable[m][2] + "," +
            currRLNode.moveTable[m][3] +
            ") leads to state with RL score: " + dbScore);
        restoreMainTable();
    }
    bestMove = getBestMove(currRLNode.moveTable);
    log("\nMOVE SELECTED: " + startNode.moveTable[bestMove][0]
        + "," + startNode.moveTable[bestMove][1] + " --> " +
        startNode.moveTable[bestMove][2] + "," +
        startNode.moveTable[bestMove][3] + "\n");
    for (i = 0; i < 4; i++) {
        AI_move[i] = currRLNode.moveTable[bestMove][i];
    }
    currRLNode.moveTable[bestMove][5].pushToHistory();
    correctHistory(color);
}
//------------------------------------------------------------
function correctHistory(color)
{
    var epsilon;

    if (moveInProgress) {
        setTimeout(function() {correctHistory(color);}, 100);
        return;
    }
    var i, value, diff;
    if (((gameType == local) && (opponents[blue] == human) &&
        (opponents[red] == human))
        || ((gameType == online) &&
        (onlinePlayerType == human)))
            return;
    logging(true);
    log("\n\n********** H I S T O R Y   s t a r t *******\n");
    for (i = 0; i < historyDepth; i++) {
        if (statusHistory[i] != undefined) {
            log("HISTORY[" + i + "]:::::::");
            log("score()=" + statusHistory[i].score(color));
            log("dbScore=" + statusHistory[i].dbScore[color]);
            statusHistory[i].displayStatusTable();
        }
    }
    log("\n\n*********** H I S T O R Y   e n d **********\n");
    log("\n\n******** HISTORY CORRECTION START **********\n");
    if ((statusHistory[1] == undefined)) {
        log("-no history-");
        log("\n******** HISTORY CORRECTION END ********\n\n");
        return;
    }
    diff = statusHistory[0].score(color) -
        statusHistory[1].score(color);
    if (diff == 0) {
        log("-no changes-");
        log("\n******** HISTORY CORRECTION END ********\n\n");
        return;
    }
    var delta = diff + gamma*statusHistory[0].dbScore[color] -
        statusHistory[1].dbScore[color];
    log("HISTORY[0]:::::::");
    statusHistory[0].displayStatusTable();
    log("hist[0] dbScore=" + statusHistory[0].dbScore[color]);
    for (i = 0; i < historyDepth; i++) {
        if (statusHistory[i] != undefined) {
            epsilon = Math.pow(gamma*lamda,
                    statusHistory.length - i);
            value = statusHistory[i].dbScore[color] +
                alpha*delta*epsilon;
            log("V(s)^" + (statusHistory.length - i) + " = "
                + statusHistory[i].dbScore[color] + " + "
                + alpha + " * " + delta + " * "
                + epsilon + " = " + value);
            if (value != statusHistory[i].dbScore[color]) {
                log("ROLL BACK: Correcting " +
                    statusHistory[i].dbScore[color] +
                    " --> " + value + " for depth " + i +
                    " with node:");
                statusHistory[i].displayStatusTable();
                statusHistory[i].updateDBRLScore(color,value);
            }
            else log("~~~~~ Not touching depth " + i +
                " (it has obj value=" +
                statusHistory[i].dbScore[color] + ")");
        }
    }
    log("\n*********** HISTORY CORRECTION END *********\n\n");
    logging(false);
}
//------------------------------------------------------------
function syncAjaxCall(url) {
    return $.ajax({
        type: "GET",
        url: url,
        async: false
    }).responseText;
}