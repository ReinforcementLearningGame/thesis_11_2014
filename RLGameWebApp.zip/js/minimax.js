var
    moveTable = [],
    startNode,
    maxDepth = 4;
//------------------------------------------------------------
function NODE(parNode, parMove, statusTable, pawnsInBase,
              moveTable, depth)
{
    this.parNode = parNode;
    this.parMove = parMove;
    this.statusTable = deepCopy(statusTable);
    this.pawnsInBase = numOfPawnsInBase.slice();
    this.moveTable = deepCopy(moveTable);
    this.depth = depth;
    this.statusScore = null;
    this.sendTermDepthToRoot = function() {
        var n = this;

        if (depth == 1) return;
        while ((n.parNode != null) &&
            (n.parNode != startNode)) n = n.parNode;
        if ((n.parNode.moveTable[n.parMove][6] == undefined)
            || (n.parNode.moveTable[n.parMove][6] > depth))
            n.parNode.moveTable[n.parMove][6] = this.depth;
    };
    this.score = function(color) {
        if (((color == blue) &&
            (this.statusTable[0][tableSize - 1] == blue))
            || ((color == red) &&
            (this.statusTable[tableSize - 1][0] == red))) {
                return 100;
        }
        if (((color == red) &&
            (this.statusTable[0][tableSize - 1] == blue))
            || ((color == blue) &&
            (this.statusTable[tableSize - 1][0] == red))) {
                return -100;
        }
        var pawns = [];
        pawns[blue] = this.pawnsInBase[blue];
        pawns[red] = this.pawnsInBase[red];
        for (var i = 0; i < tableSize; i++)
            for (var j = 0; j < tableSize; j++)
                if ((this.statusTable[i][j] != blank) &&
                    (!tileInBase(i, j, blue)) &&
                    (!tileInBase(i, j, red)))
                    pawns[this.statusTable[i][j]]++;
        var result = 100*(pawns[color] -
            pawns[enemyColor(color)])/numberOfPawns;
        return result;
    };
    this.score(blue);
    this.displayStatusTable = function() {
        displayTable("-- statusTable:", this.statusTable);
    };
    this.cleanupBases = function() {
        var win = blank;
        for (var i = tableSize - baseSize; i < tableSize; i++)
            for (var j = 0; j < baseSize; j++) {
                if (this.statusTable[i][j] == red) win = red;
                this.statusTable[i][j] = blank;
            }
        if (win == red) {
            this.statusTable[tableSize - 1][0] = red;
            this.pawnsInBase[blue] = 0;
        }
        else if (this.pawnsInBase[blue] > 0)
            this.statusTable[tableSize - 1][0] = blue;
        for (i = 0; i < baseSize; i++)
            for (j = tableSize-baseSize; j < tableSize; j++) {
                if (this.statusTable[i][j] == blue) win= blue;
                this.statusTable[i][j] = blank;
            }
        if (win == blue) {
            this.statusTable[0][tableSize - 1] = blue;
            this.pawnsInBase[red] = 0;
        }
        else if (this.pawnsInBase[red] > 0)
            this.statusTable[0][tableSize - 1] = red;
    };
    if (this.statusTable[tableSize-1][0] == blank)
        this.pawnsInBase[blue] = 0;
    if (this.statusTable[0][tableSize-1] == blank)
        this.pawnsInBase[red] = 0;
    this.cleanupBases();
}
//------------------------------------------------------------
function getMinimaxMove(color)
{
    var best;
    var mTable = [];
    moveTable = [];
    startNode = null;
    backupMainTable();
    logging(true);
    log("\n=== MINIMAX started (depth: " + maxDepth + ") ==");
    if (useRL) {
        var currRLNode =
            new RLNODE(mainTable, numOfPawnsInBase, mTable);
        currRLNode.lookupDBRLScore(color);
        currRLNode.pushToHistory();
        correctHistory(color);
    }
    logging(false);
    collectAvailMoves(color, moveTable);
    logging(false);
    startNode = new NODE(null, null, mainTable,
        numOfPawnsInBaseBackup, moveTable, 1);
    createChildren(startNode, color, color);
    log("******* STARTING EVALUATING PATHS! ***************");
    evalPaths(startNode, color);
    log("******* FINISHED EVALUATING PATHS! ***************");
    restoreMainTable();
    logging(true);
    for (var m=0; m < startNode.moveTable.length; m++)
       log("#" + (m+1) + " MOVE : "+startNode.moveTable[m][0]
           + ","+startNode.moveTable[m][1]+" --> "
           + startNode.moveTable[m][2]+","
           + startNode.moveTable[m][3]+" , SCORE: "
           + startNode.moveTable[m][4] + "  ("
           + (startNode.moveTable[m][6]+1) +")");
    log("\n");
    best = getMaxScorePos(startNode.moveTable, 4,
        startNode.score(color));
    if (best >= 0) {
        log("\nMOVE SELECTED : " +
            startNode.moveTable[best][0] + "," +
            startNode.moveTable[best][1] + " --> " +
            startNode.moveTable[best][2] + "," +
            startNode.moveTable[best][3]);
        for (var i = 0; i < 4; i++)
            AI_move[i] = startNode.moveTable[best][i];
        if (useRL) {
            pushToHistoryMinimaxMove(
                startNode.moveTable[best][5], color);
            correctHistory(color);
        }
    }
    log("===== MINIMAX ended ============================\n");
    logging(false);
}
//------------------------------------------------------------
function pushToHistoryMinimaxMove(minimaxNode, color)
{
    var pib;
    var sTable = deepCopy(minimaxNode.statusTable);
    var mTable = [];
    backupMainTable();
    mainTable = deepCopy(sTable);
    numOfPawnsInBase = minimaxNode.pawnsInBase.slice();
    virtualCheckForVanishes();
    sTable = deepCopy(mainTable);
    pib = numOfPawnsInBase.slice();
    restoreMainTable();
    var rlNode = new RLNODE(sTable, pib, mTable);
    rlNode.lookupDBRLScore(color);
    rlNode.pushToHistory();
}
//------------------------------------------------------------
function createChildren(parentNode, whoIsAI, whoPlays)
{
    var childNode, m;
    if (parentNode.depth > maxDepth) return;
    for (m = 0; m < parentNode.moveTable.length; m++) {
        moveTable = [];
        mainTable = deepCopy(parentNode.statusTable);
        numOfPawnsInBase = parentNode.pawnsInBase.slice();
        doVirtualMove(whoPlays, parentNode.moveTable, m);
        virtualCheckForVanishes();
        collectAvailMoves(enemyColor(whoPlays), moveTable);
        childNode = new NODE(parentNode, m, mainTable,
            numOfPawnsInBase, moveTable, parentNode.depth+ 1);
        parentNode.moveTable[m][5] = childNode;
        createChildren(childNode, whoIsAI,
            enemyColor(whoPlays));
    }
}
//------------------------------------------------------------
function evalPaths(theNode, color)
{
    log("\n\nevaluating depth=" + theNode.depth +
        " subtree of:");
    displayTable("", theNode.statusTable);
    if (theNode.depth <= maxDepth) {
        for (var m = 0; m < theNode.moveTable.length; m++) {
            log("\nevaluating child " + (m+1) + "/" +
                theNode.moveTable.length+" (depth=" +
                (theNode.depth+1)+"  -  move " +
                theNode.moveTable[m][0]+"," +
                theNode.moveTable[m][1]+" --> " +
                theNode.moveTable[m][2]+"," +
                theNode.moveTable[m][3]+"):");
            evalPaths(theNode.moveTable[m][5], color);
            theNode.moveTable[m][4] =
                theNode.moveTable[m][5].statusScore;
            log("(depth="+(theNode.depth+1)+") child Score= "
                + theNode.moveTable[m][4]);
        }
        if (theNode.depth % 2 != 0) {
            if (theNode.moveTable.length > 0)
                theNode.statusScore =
                    getMaxScore(theNode.moveTable, 4);
        }
        else {
            if (theNode.moveTable.length > 0)
                theNode.statusScore =
                    getMinScore(theNode.moveTable, 4);
        }
        if (theNode.score(color) == theNode.statusScore)
            theNode.sendTermDepthToRoot();
        if ((theNode.score(color) == 100) ||
            (theNode.score(color) == -100)) {
            theNode.statusScore = theNode.score(color);
            theNode.sendTermDepthToRoot();
        }
    }
    else {
        log("maximum depth reached:");
        theNode.displayStatusTable();
        theNode.statusScore = theNode.score(color);
        theNode.sendTermDepthToRoot();
    }
}
//------------------------------------------------------------
function getMinLossMove(tbl)
{
    var m, max, pos, pos2;
    var maximums = [];
    max = tbl[0][6];
    pos = 0;
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][6] > max) {
            max = tbl[m][6];
            pos = m;
        }
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][6] == max) maximums.push(tbl[m]);
    if (maximums.length > 1) {
        pos2 = getMaxGainMove(maximums);
        for (m = 0; m < tbl.length; m++) {
            if ((maximums[pos2][0] == tbl[m][0])
                && (maximums[pos2][1] == tbl[m][1])
                && (maximums[pos2][2] == tbl[m][2])
                && (maximums[pos2][3] == tbl[m][3]))
                    return m;
        }
    }
    else return pos;
}
//------------------------------------------------------------
function getMaxGainMove(tbl)
{
    var m, max, pos;
    var maximums = [];
    max = tbl[0][7];
    pos = 0;
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][7] > max) {
            max = tbl[m][7];
            pos = m;
        }
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][7] == max) maximums.push(m);
    if (maximums.length > 1)
        return maximums[Math.floor(Math.random()*
            (maximums.length))];
    else return pos;
}
//------------------------------------------------------------
function getMinScore(tbl, col)
{
    var m, min;
    min = tbl[0][col];
    for (m = 0; m < tbl.length; m++) {
        if (tbl[m][col] < min) min = tbl[m][col];
    }
    return min;
}
//------------------------------------------------------------
function getMaxScore(tbl, col)
{
    var m, max;
    max = tbl[0][col];
    for (m = 0; m < tbl.length; m++) {
        if (tbl[m][col] > max) max = tbl[m][col];
    }
    return max;
}
//------------------------------------------------------------
function getMaxScorePos(tbl, col, nowScore)
// [0]-[3] : move
// [4] : score ("col" param)
// [5] : pointer to node
// [6] : score depth
{
    var m, min, minpos, max, pos;
    var maximums = [];
    var minimums = [];
    var movesForRL = [];
    max = tbl[0][col];
    pos = 0;
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][col] > max) {
            max = tbl[m][col];
            pos = m;
        }
    for (m = 0; m < tbl.length; m++)
        if (tbl[m][col] == max) {
            maximums.push(m);
            log("Adding move #"+(m+1)+" to candidates.");
        }
    if (maximums.length == 1) return pos;
    else {
        min = tbl[maximums[0]][6];
        minpos = 0;
        if (tbl[maximums[0]][4] >= nowScore) {
            for (m = 0; m < maximums.length; m++) {
                if (tbl[maximums[m]][6] < min) {
                    min = tbl[maximums[m]][6];
                    minpos = m;
                }
            }
        }
        else {
            for (m = 0; m < maximums.length; m++) {
                if (tbl[maximums[m]][6] > min) {
                    min = tbl[maximums[m]][6];
                    minpos = m;
                }
            }
        }
        log("\n");
        for (m = 0; m < maximums.length; m++) {
            if (tbl[maximums[m]][6] == min) {
                log("Adding move #"+ (maximums[m]+1) +
                    " to optimal candidates.");
                minimums.push(maximums[m]);
            }
        }
        if (minimums.length == 1) {
            log("\nSelecting move for optimal " +
                "time management.");
            return maximums[minpos];
        }
        else {
            if (!useRL) {
                log("\nMany candidates same, " +
                    "selecting random...");
                return minimums[Math.floor(Math.random()*
                    (minimums.length))];
            }
            else {
                log("\nMany candidates same, " +
                    "switching to RL...");
                for (m = 0; m < minimums.length; m++)
                    movesForRL.push(tbl[minimums[m]]);
                getRLMove(playerTurn, movesForRL);
                return -1;
            }
        }
    }
}
//------------------------------------------------------------
function displayTable(name, t)
{
    var s, c;
    log("\n" + name);
    for (var i = 0; i < tableSize; i++) {
        s = "";
        for (var j = 0; j < tableSize; j++) {
            if (t[i][j] == blue) c = "[b]";
            else if (t[i][j] == red) c = "[r]";
            else c = "[ ]";
            s += c;
        }
        log(s);
    }
    log("\n\n");
}
//------------------------------------------------------------
function virtualCheckForVanishes()
{
    var vanishTable = new Array(tableSize);
    for (var i = 0; i < tableSize; i++) {
        vanishTable[i] = new Array(tableSize);
        for (var j = 0; j < tableSize; j++)
            vanishTable[i][j]= ((getTileStatus(i, j) != blank)
                && (numOfValidMoves(i, j) == 0));
    }
    for (i = 0; i < tableSize; i++)
        for (j = 0; j < tableSize; j++)
            if (vanishTable[i][j]) {
                mainTable[i][j] = blank;
                if (tileInBase(i, j, blue))
                    numOfPawnsInBase[blue] = 0;
                else if (tileInBase(i, j, red))
                    numOfPawnsInBase[red] = 0;
            }
}