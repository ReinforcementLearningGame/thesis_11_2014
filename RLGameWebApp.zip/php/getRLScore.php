﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";
		
	$sql = "SELECT ".$_GET["color"]."_score FROM rl WHERE hash='" . $_GET["hash"] . "';";
	//echo "<br>Executing: " . $sql;

	$result = mysqli_query($conn, $sql);

	$row = mysqli_fetch_assoc($result);
	
	if ($row) {
		echo $row[$_GET["color"]."_score"];
		mysqli_free_result($result);
	}	
	else {
		$sql = "INSERT INTO rl (hash, blue_score, red_score) VALUES ('".$_GET["hash"] . "', 0, 0);";
		//echo "<br>Executing: " . $sql;
		$result = mysqli_query($conn, $sql);
		echo "0";
	}

	mysqli_close($conn);	
	
?>
