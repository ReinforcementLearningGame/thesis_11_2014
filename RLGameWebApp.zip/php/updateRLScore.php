﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";
		
	$sql = "UPDATE rl SET blue_score=" . $_GET["blue_score"] . ", red_score=" . $_GET["red_score"] . " WHERE hash='" . $_GET["hash"] . "';";
	//echo "<br>Executing: " . $sql;
	mysqli_query($conn, $sql);

	echo $sql;
	
	mysqli_close($conn);	
	
?>
