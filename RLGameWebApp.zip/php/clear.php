﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";
		
	$sql = "UPDATE main SET " . $_GET["color"] . "i1=-1, " . $_GET["color"] . "j1=-1, " . $_GET["color"] . "i2=-1, " . $_GET["color"] . "j2=-1 WHERE game_id='" . $_GET["gid"] . "';";
	//echo "<br>Executing: " . $sql;

	$result = mysqli_query($conn, $sql);

	//echo "result = ".$result;
	mysqli_close($conn);	
	
?>
