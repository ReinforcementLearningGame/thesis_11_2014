﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";

	
	if ($_GET["color"] == 0) $col = "blue";
	else $col = "red";
	
	
	$sql = "UPDATE main SET " . $col . "_last_access='" . date("Y-m-d H:i:s") . "', " . $col . "_i1=" . $_GET["i1"] . ", " . $col . "_j1=" . $_GET["j1"] . ", " . $col . "_i2=" . $_GET["i2"] . ", " . $col . "_j2=" . $_GET["j2"] . " WHERE game_id='" . $_GET["gid"] . "';";

	//echo "<br>Executing: " . $sql;
	$result = mysqli_query($conn, $sql);

	mysqli_close($conn);	
	
?>
