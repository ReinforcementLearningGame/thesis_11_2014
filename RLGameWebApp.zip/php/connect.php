﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";
		
	$sql = "SELECT * FROM main WHERE game_id='" . $_GET["gid"] . "';";
	//echo "<br>Executing: " . $sql;

	$result = mysqli_query($conn, $sql);
	$n = mysqli_num_rows($result);
	mysqli_free_result($result);

	if ($n == 0) {
		//echo "<br>GameID not found, creating a new one...";
		$sql = "INSERT INTO main (game_id, blue_last_access, blue_i1, blue_j1, blue_i2, blue_j2, red_i1, red_j1, red_i2, red_j2) VALUES ('".$_GET["gid"] . "', '" . date("Y-m-d H:i:s") . "', -1, -1, -1, -1, -1, -1, -1, -1);";
		//echo "<br>Executing: " . $sql;
		$result = mysqli_query($conn, $sql);
		
		if (!$result) {
			//echo "<br>Failed to insert record to database: " . mysqli_error($conn);
			exit();
		}
		
		$sql = "INSERT INTO main (game_id, blue_last_access, blue_i1, blue_j1, blue_i2, blue_j2, red_i1, red_j1, red_i2, red_j2) VALUES ('" . $_GET["gid"] . ":settings" . "', '" . date("Y-m-d H:i:s") . "', -1, -1, -1, -1, -1, -1, -1, -1);";
		//echo "<br>Executing: " . $sql;
		$result = mysqli_query($conn, $sql);
		
		if (!$result) {
			//echo "<br>Failed to insert record to database: " . mysqli_error($conn);
			exit();
		}

		echo "0";
	}
	else {
	
	
    	$sql = "SELECT red_last_access FROM main WHERE game_id='" . $_GET["gid"] . "';";
    	//echo "<br>Executing: " . $sql;

	    $result = mysqli_query($conn, $sql);

    	$row = mysqli_fetch_assoc($result);
		
		mysqli_free_result($result);
	
    	if ($row["red_last_access"] != "") {
    		//echo "<br>Executing: " . $sql;
    		echo "-1";
    	}
    	else {
    		$sql = "UPDATE main SET red_last_access='" . date("Y-m-d H:i:s") . "' WHERE game_id='" . $_GET["gid"] . "';";
    		//echo "<br>Executing: " . $sql;
    		$result = mysqli_query($conn, $sql);
    		echo "1";
    	}
    }

	mysqli_close($conn);	
	
?>
