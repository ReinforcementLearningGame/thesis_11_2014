﻿<?php 

	$conn = mysqli_connect("localhost","edw_to_username","edw_to_password","edw_to_onoma_tis_vasis");

	if (mysqli_connect_errno()) {
		//echo "Failed to connect to database: " . mysqli_connect_error();
		exit();
	}

	//echo "Connection successfull!";
		
	$sql = "SELECT " . $_GET["field"] . " FROM main WHERE game_id='" . $_GET["gid"] . "';";
	//echo "<br>Executing: " . $sql;

	$result = mysqli_query($conn, $sql);

	$row = mysqli_fetch_assoc($result);
	
	if ($row) echo $row[$_GET["field"]];

	mysqli_free_result($result);
	mysqli_close($conn);	
	
?>
