﻿<?php 

	$link = mysql_connect('localhost', 'edw_to_username', 'edw_to_password') or die(mysql_error());
	mysql_select_db("edw_to_onoma_tis_vasis", $link) or die(mysql_error());
	mysql_query("DELETE from rl", $link) or die(mysql_error());
	mysql_close($link);

	echo "<pre>";
    echo "<br>       /(|";
    echo "<br>      (  :";
    echo "<br>     __\  \  _____";
    echo "<br>   (____)  `|";
    echo "<br>  (____)|   |";
    echo "<br>   (____).__|";
    echo "<br>    (___)__.|_____";

	echo "<br><br>        Done!";
	echo "</pre>";
?>
